package com.example.todoapp.presentation.themes

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.MaterialTheme
import androidx.compose.material.darkColors
import androidx.compose.material.lightColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider

@Composable
fun AppTheme(theme: Theme, content: @Composable () -> Unit) {
    val themeColors = if (isSystemInDarkTheme()) {
        ColorNames(
            supportSeparator = theme.darkSupportSeparator,
            supportOverlay = theme.darkSupportOverlay,
            labelPrimary = theme.darkLabelPrimary,
            labelSecondary = theme.darkLabelSecondary,
            labelTertiary = theme.darkLabelTertiary,
            labelDisable = theme.darkLabelDisable,
            colorRed = theme.darkRed,
            colorGreen = theme.darkGreen,
            colorBlue = theme.darkBlue,
            colorGray = theme.darkGray,
            colorGreyLight = theme.darkGrayLight,
            colorWhite = theme.darkWhite,
            backPrimary = theme.darkBackPrimary,
            backSecondary = theme.darkBackSecondary,
            backElevated = theme.darkBackElevated,
        )
    }
    else {
        ColorNames(
            supportSeparator = theme.lightSupportSeparator,
            supportOverlay = theme.lightSupportOverlay,
            labelPrimary = theme.lightLabelPrimary,
            labelSecondary = theme.lightLabelSecondary,
            labelTertiary = theme.lightLabelTertiary,
            labelDisable = theme.lightLabelDisable,
            colorRed = theme.lightRed,
            colorGreen = theme.lightGreen,
            colorBlue = theme.lightBlue,
            colorGray = theme.lightGray,
            colorGreyLight = theme.lightGrayLight,
            colorWhite = theme.lightWhite,
            backPrimary = theme.lightBackPrimary,
            backSecondary = theme.lightBackSecondary,
            backElevated = theme.lightBackElevated,
        )
    }
    CompositionLocalProvider(LocalColorNames provides themeColors) {
        MaterialTheme(
            colors = if (isSystemInDarkTheme()) darkColors() else lightColors(),
            content = content
        )
    }
}

val themeColors: ColorNames
    @Composable
    get() = LocalColorNames.current
